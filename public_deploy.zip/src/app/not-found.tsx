const NotFound = () => {
  return <div>Not found - 404 Error</div>;
};

export default NotFound;
