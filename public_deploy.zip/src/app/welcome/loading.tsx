"use client";

import WelcomePageSkeleton from "@/components/skeletons/welcomePageSkeleton";

const Loading = () => {
  return <WelcomePageSkeleton />;
};

export default Loading;
