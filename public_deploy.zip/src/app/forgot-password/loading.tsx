"use client";

const Loading = () => {
  return <p>Loading...</p>;
};

export default Loading;
