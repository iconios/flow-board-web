import ForgotPassword from "@/components/welcome/forgot-password.component";

const ForgotPasswordPage = () => {
  return <ForgotPassword />;
};

export default ForgotPasswordPage;
